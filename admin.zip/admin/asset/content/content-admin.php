<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	
	      <div class="row">
	      	
	      	<div class="span12">      		
	      		
	      		<div class="widget ">
	      			
	      			<div class="widget-header">
	      				<i class="icon-cog"></i>
	      				<h3>Panel Admin</h3>
	  				</div> <!-- /widget-header -->
					
					<div class="widget-content">
						
						
						
						<div class="tabbable">
							<ul class="nav nav-tabs">
							<li class="active"><a href="#dashboard" data-toggle="tab">Statistik</a>
							<li><a href="#admin" data-toggle="tab">Kelola Admin</a>
							</li>
							</ul>
							
							<br>
							
								<div class="tab-content">
									<div class="tab-pane active" id="dashboard">
										<?php include 'asset/admin/content-dashboard.php' ?>
									</div>
									<div class="tab-pane" id="admin">
										<?php include 'asset/admin/content-admin.php' ?>
									</div>
									
									
									
								</div>
						  
						  
						</div>
						
						
						
						
						
					</div> <!-- /widget-content -->
						
				</div> <!-- /widget -->
	      		
		    </div> <!-- /span8 -->
	      	
	      	
	      	
	      	
	      </div> <!-- /row -->
	
	    </div> <!-- /container -->
	    
	</div> <!-- /main-inner -->
    
</div> <!-- /main -->