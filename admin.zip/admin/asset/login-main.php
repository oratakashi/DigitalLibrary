<div class="app app-fh">

            <!-- START APP CONTAINER -->   
            <div class="app-container" style="background: url(images/bg-1.jpg) center center no-repeat fixed;">
                <center><img src="../proyek/images/logo.png" style="margin-top:30px"></img></center>
                <div class="app-login-box" style="margin-top:10px">
                    <a href="../"><button class="btn btn-danger" style="float:right;margin-top:5px;margin-right:5px;padding-top:2px">X</button></a>
                    <div class="app-login-box-user"><img src="images/no-image.png"></div>
                    <div class="app-login-box-title">
                        <div class="title">Login - Admin Panel</div>
                        <div class="subtitle">Masukan Username dan Password</div>                         

                    </div>
                    <div class="app-login-box-container">
                        <form action="login.php" method="post">
                            <div class="form-group">
                                <input type="text" class="form-control" name="username" placeholder="Username">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="password" placeholder="Password">
                            </div>
                            <div class="form-group">

                                <div class="row">
                                    <div class="col-md-12 col-xs-12">
                                        <input type="submit" value="Login" class="btn btn-success btn-block" name="submit">
                                    </div>
                                </div>
                                
                            </div>
                        </form>
                    </div>
                    <div class="app-login-box-footer">
                        &copy; 2018 Digital Library. All Rights Reserved <br> Design by <a href='https://github.com/oratakashi'>Politeknik Negeri Bandung</a>
                    </div>
                </div>
                                 
            </div>
            <!-- END APP CONTAINER -->
           
        </div> 