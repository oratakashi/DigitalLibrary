<div class="inner_content">
				    <!-- /inner_content_w3_agile_info-->

					<!-- breadcrumbs -->
						
					<!-- //breadcrumbs -->

					<div class="inner_content_w3_agile_info two_in">
					  <h2 class="w3_inner_tittle">Halaman Daftar Buku</h2>

							<!-- /blank -->
								<div class="blank_w3ls_agile">
									<div class="blank-page agile_info_shadow">
										<p>Ini adalah Daftar Buku</p>
									</div>
								</div>
							<!-- //blank -->
					
							
				    </div>
					<!-- //inner_content_w3_agile_info-->
				</div>