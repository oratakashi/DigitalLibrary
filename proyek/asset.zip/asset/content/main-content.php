<div class="inner_content">
					<div class="inner_content_w3_agile_info two_in">
					<?php include 'asset/content/slider.php'?>
					<?php include '../asset/content/slider.php'?>
					  	<h2 class="w3_inner_tittle">Sedang Hangat</h2>
							<!-- /blank -->
								<div class="warning_w3ls_agile">
									<div class="blank-page agile_info_shadow">
										
										<p>Maaf perangkat anda tidak support untuk membuka digital library</p>
									</div>
								</div>
								<div class="blank_w3ls_agile">
									<div class="blank-page agile_info_shadow">
										<div class="row">
											<div class="col-sm-6 col-md-3">
												<div class="thumbnail">
													<a  href="">
														<img src="images/park.jpg" alt="Park">
													</a>
													<div class="caption">
														<center><h3>Thumbnail label</h3></center><br>
														<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
													</div>
												</div>
											</div>
											<div class="col-sm-6 col-md-3">
												<div class="thumbnail">
													<a  href="index.php?page=produk">
														<img src="images/park.jpg" alt="Park">
													</a>
													<div class="caption">
														<center><h3>Thumbnail label</h3></center><br>
														<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
													</div>
												</div>
											</div>
											<div class="col-sm-6 col-md-3">
												<div class="thumbnail">
													<a  href="">
														<img src="images/park.jpg" alt="Park">
													</a>
													<div class="caption">
														<center><h3>Thumbnail label</h3></center><br>
														<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
													</div>
												</div>
											</div>
											<div class="col-sm-6 col-md-3">
												<div class="thumbnail">
													<a  href="">
														<img src="images/park.jpg" alt="Park">
													</a>
													<div class="caption">
														<center><h3>Thumbnail label</h3></center><br>
														<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							<!-- //blank -->
							<h2 class="w3_inner_tittle">Rekomendasi</h2>
							<!-- /blank -->
								<div class="warning_w3ls_agile">
									<div class="blank-page agile_info_shadow">
										
										<p>Maaf perangkat anda tidak support untuk membuka digital library</p>
									</div>
								</div>
								<div class="blank_w3ls_agile">
									<div class="blank-page agile_info_shadow">
										<div class="row">
										<div class="col-sm-6 col-md-3">
												<div class="thumbnail">
													<a  href="">
														<img src="images/park.jpg" alt="Park">
													</a>
													<div class="caption">
														<center><h3>Thumbnail label</h3></center><br>
														<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
													</div>
												</div>
											</div>
											<div class="col-sm-6 col-md-3">
												<div class="thumbnail">
													<a  href="">
														<img src="images/park.jpg" alt="Park">
													</a>
													<div class="caption">
														<center><h3>Thumbnail label</h3></center><br>
														<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
													</div>
												</div>
											</div>
											<div class="col-sm-6 col-md-3">
												<div class="thumbnail">
													<a  href="">
														<img src="images/park.jpg" alt="Park">
													</a>
													<div class="caption">
														<center><h3>Thumbnail label</h3></center><br>
														<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
													</div>
												</div>
											</div>
											<div class="col-sm-6 col-md-3">
												<div class="thumbnail">
													<a  href="">
														<img src="images/park.jpg" alt="Park">
													</a>
													<div class="caption">
														<center><h3>Thumbnail label</h3></center><br>
														<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							<!-- //blank -->
					
							
				    </div>
					<!-- //inner_content_w3_agile_info-->
				</div>