<section id="jms-slideshow" class="jms-slideshow">
				<div class="step" data-color="color-2">
					<div class="jms-content">
						<h3>Baca buku kini lebih mudah...</h3>
					<p>Kini tak perlu pergi jauh ke toko ataupun perpustakaan, dengan Digital Library baca buku jadi lebih mudah</p>
					</div>
					<img src="images/1.png" />
					<img src="../images/1.png" />
				</div>
				<div class="step" data-color="color-3" data-y="900" data-rotate-x="80">
					<div class="jms-content">
						<h3>Tak perlu antri lagi...</h3>
					<p>Bosan antre dalam perpustakaan hanya untuk meminjam buku? , kini sudah tidak perlu antri lagi</p>
					</div>
					<img src="images/2.png" />
					<img src="../images/2.png" />
				</div>
				<div class="step" data-color="color-4" data-x="-100" data-z="1500" data-rotate="170">
					<div class="jms-content">
						<h3>Tidak perlu ruang lebih untuk menyimpan buku</h3>
					<p>Bingung anda tak punya lemari untuk menyimpan buku? kini Digital Library dapat jadi solusi</p>
					</div>
					<img src="images/3.png" />
					<img src="../images/3.png" />
				</div>
				<div class="step" data-color="color-5" data-x="3000">
					<div class="jms-content">
						<h3>Gratis dan Legal...</h3>
					<p>Males cari buku di Google secara ilegal? dengan Digital Library kini lebih mudah dan legal</p>
						<a class="jms-link" href="#">Baca Sekarang</a>
					</div>
					<img src="images/4.png" />
					<img src="../images/4.png" />
				</div>
				<div class="step" data-color="color-1" data-x="4500" data-z="1000" data-rotate-y="45">
					<div class="jms-content">
						<h3>Waktu adalah Uang...</h3>
					<p>Tak punya waktu lebih untuk ke perpustakaan? dengan Digital Library anda bisa hemat waktu anda</p>
					</div>
					<img src="images/5.png" />
					<img src="../images/5.png" />
				</div>
			</section>