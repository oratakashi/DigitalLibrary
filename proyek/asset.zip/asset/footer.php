<div class="copyrights">
	 <p>© 2018 Digital Library. All Rights Reserved | Design by  <a href="http://github.com/oratakashii" target="_blank">Politeknik Negeri Bandung</a> </p>
</div>