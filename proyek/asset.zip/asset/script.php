<!-- Main Script -->

<!-- Sciprt Untuk Import JQuery dan Bootstrap -->
<script type="text/javascript" src="asset/js/bootstrap-3.1.1.min.js"></script>
<script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
<!-- Load Addons Script -->
<?php include 'asset/slider-script.php'?>
<script type="text/javascript" src="asset/js/jmpress.min.js"></script>
<script type="text/javascript" src="js/jquery.jmslideshow.js"></script>
<script type="text/javascript" src="js/modernizr.custom.48780.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/classie.js"></script>
<script src="js/gnmenu.js"></script>
<script>new gnMenu( document.getElementById( 'gn-menu' ) );</script>
<script type="text/javascript" src="js/circles.js"></script>
<script src="js/skycons.js"></script>
<script src="js/bars.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>

<!-- Users Script -->

<!-- Sciprt Untuk Import JQuery dan Bootstrap -->
<script type="text/javascript" src="../asset/js/bootstrap-3.1.1.min.js"></script>
<script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
<!-- Load Addons Script -->
<?php include '../asset/slider-script.php'?>
<script type="text/javascript" src="../asset/js/jmpress.min.js"></script>
<script type="text/javascript" src="../js/jquery.jmslideshow.js"></script>
<script type="text/javascript" src="../js/modernizr.custom.48780.js"></script>
<script src="../js/modernizr.custom.js"></script>
<script src="../js/classie.js"></script>
<script src="../js/gnmenu.js"></script>
<script>new gnMenu( document.getElementById( 'gn-menu' ) );</script>
<script type="../text/javascript" src="js/circles.js"></script>
<script src="../js/skycons.js"></script>
<script src="../js/bars.js"></script>
<script src="../js/jquery.nicescroll.js"></script>
<script src="../js/scripts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>

<script>
    baguetteBox.run('.blank_w3ls_agile');
</script>