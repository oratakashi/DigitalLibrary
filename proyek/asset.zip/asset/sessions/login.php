<div class="login_content">
	<div class="login_content_w3_agile_info">
		<div class="registration admin_agile">				
			<div class="signin-form profile admin">
				<h2>Login Anggota</h2>
				<p id="validasi" style="color: #ff0000"></p>
				<div class="login-form">
					<form action="" method="post" class="form">
						<input type="text" name="username" placeholder="Email" required="" id="username">
						<input type="password" name="password" placeholder="Password" required="" id="password">
						<div class="tp">
							<input type="submit" name="submit" id="submit" value="LOGIN">
						</div>				
					</form>
				</div>
			</div>
		</div>			
	</div>
</div>