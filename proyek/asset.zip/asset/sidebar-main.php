<div class="gn-scroller scrollbar1">
							<ul class="gn-menu agile_menu_drop">
								<li><a href="index.php"> <i class="fa fa-home"></i> Beranda</a></li>
								<li><a href="#"><i class="fa fa-user" aria-hidden="true"></i> Akun <i class="fa fa-angle-down" aria-hidden="true"> </i></a> 
								     	<ul class="gn-submenu">
										<li class="mini_list_agile" ><a href="index.php?page=login"><i class="fa fa-caret-right" aria-hidden="true"></i> Login</a></li>
										
									</ul>
								</li>
								<li>
									<a href="index.php?page=kategori"><i class="fa fa-list" aria-hidden="true"></i> Kategori </a> 
								</li>
								<li><a href="index.php?page=daftarbuku"> <i class="fa fa-book" aria-hidden="true"></i> Daftar Buku</a></li>								
							</ul>
						</div>