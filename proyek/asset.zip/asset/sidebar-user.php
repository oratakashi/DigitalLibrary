<div class="gn-scroller scrollbar1">
							<ul class="gn-menu agile_menu_drop">
								<li>	
									<span class="prfil-img"><img src="../images/a1.jpg" alt=""> </span>Administrator</li>
								<li><a href="index.php?session=user"> <i class="fa fa-home"></i> Beranda</a></li>
								<li>
									<a href="#"><i class="fa fa-list" aria-hidden="true"></i> Kategori <i class="fa fa-angle-down" aria-hidden="true"></i></a> 
									<ul class="gn-submenu">
										<li class="mini_list_agile"><a href="buttons.html"><i class="fa fa-caret-right" aria-hidden="true"></i> Kategori Buku</a></li>
										<li class="mini_list_w3"><a href="grids.html"> <i class="fa fa-caret-right" aria-hidden="true"></i> Kategori Tugas Akhir</a></li>
									</ul>
								</li>
								<li><a href="charts.html"> <i class="fa fa-book" aria-hidden="true"></i> Daftar Buku</a></li>								
								<li><a href="charts.html"> <i class="fa fa-line-chart" aria-hidden="true"></i> Rekomendasi</a></li>
								<li><a href="#"><i class="fa fa-user" aria-hidden="true"></i> Akun <i class="fa fa-angle-down" aria-hidden="true"> </i></a> 
								     	<ul class="gn-submenu">
										<li class="mini_list_agile"><a href="typo.html"><i class="fa fa-caret-right" aria-hidden="true"></i> Pengaturan Akun</a></li>
										<li class="mini_list_w3"><a href="logout.php"> <i class="fa fa-caret-right" aria-hidden="true"></i> Log Out</a></li>
										
									</ul>
								</li>
							</ul>
						</div>