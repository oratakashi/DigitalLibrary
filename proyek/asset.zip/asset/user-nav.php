<div class="w3_agileits_top_nav">
			<ul id="gn-menu" class="gn-menu-main">
			  		 <!-- /nav_agile_w3l -->
				<li class="gn-trigger">
					<a class="gn-icon gn-icon-menu"><i class="fa fa-bars" aria-hidden="true"></i><span>Menu</span></a>
					<nav class="gn-menu-wrapper">

						<?php include 'sidebar-user.php'?>
						
					</nav>
				</li>
				<!-- //nav_agile_w3l -->
				<li class="second logo"><h1><a href="#"><i class="fa fa-graduation-cap" aria-hidden="true"></i>Digital Library </a></h1></li>
					<li class="second admin-pic">
				       
				</li>
				<li class="second top_bell_nav"></li>
				<li class="second top_bell_nav"></li>
				<li class="second top_bell_nav"></li>

				<li class="second w3l_search">
				 
						<form action="#" method="post">
							<input type="search" name="search" placeholder="Cari Judul Buku, Pengarang, Dan Lainya.." required="">
							<button class="btn btn-default" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
						</form>
					
				</li>
				<li class="second full-screen"></li>

			</ul>
			<!-- //nav -->
			
		</div>